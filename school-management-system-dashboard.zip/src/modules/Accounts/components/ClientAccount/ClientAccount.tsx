import React from "react";

const ClientAccount: React.FC = () => {
  return (
    <React.Fragment>
      <h1>ClientAccount under construction...</h1>
    </React.Fragment>
  );
};

export default ClientAccount;
