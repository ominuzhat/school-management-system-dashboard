import React from "react";

const BalanceAdjustment: React.FC = () => {
  return (
    <React.Fragment>
      <h1>BalanceAdjustment under construction...</h1>
    </React.Fragment>
  );
};

export default BalanceAdjustment;
