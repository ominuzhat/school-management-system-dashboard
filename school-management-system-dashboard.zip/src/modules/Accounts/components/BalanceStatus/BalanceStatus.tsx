import React from "react";

const BalanceStatus: React.FC = () => {
  return (
    <React.Fragment>
      <h1>BalanceStatus under construction...</h1>
    </React.Fragment>
  );
};

export default BalanceStatus;
