import React from "react";

const TransactionsHistory: React.FC = () => {
  return (
    <React.Fragment>
      <h1>TransactionsHistory under construction...</h1>
    </React.Fragment>
  );
};

export default TransactionsHistory;
