export interface IGetFee {
  id: number;
  payroll: number;
  name: string;
  amount: number;
  one_time: boolean;
}
