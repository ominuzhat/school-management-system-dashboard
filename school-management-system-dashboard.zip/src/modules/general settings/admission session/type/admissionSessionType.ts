export interface IAdmissionSession {
  id: number;
  name: string;
  status: string;
  institution: number;
}
