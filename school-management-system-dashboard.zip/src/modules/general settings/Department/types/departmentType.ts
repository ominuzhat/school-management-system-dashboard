export interface ICreateDepartment {
  name: string;
}

export interface IGetDepartment {
  id: number;
  name: string;
}
