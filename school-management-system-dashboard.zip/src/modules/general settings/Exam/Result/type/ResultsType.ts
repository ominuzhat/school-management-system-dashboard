
export interface IResults {
  id: number;
  name: string;
  description: string;
}
