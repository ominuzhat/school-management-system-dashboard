export interface ICreateTerm {
  name: string;
}
export interface IGetTerm {
  name: string;
}
