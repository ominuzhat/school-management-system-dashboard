export interface ICreateExamReceipt {
  exam: number;
  hall: number;
  assigned_admissions: number[];
}
export interface IGetExamReceipt {
  exam: number;
  hall: number;
  assigned_admissions: number[];
}
